export function searchAddonValidTerm(v){return !!(v && v.length > 0);}
export function searchAddonEngineTerm(v){return !!v && v.length !== 0;}