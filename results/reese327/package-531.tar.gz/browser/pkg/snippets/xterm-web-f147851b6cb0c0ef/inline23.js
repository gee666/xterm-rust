export function devicePixelPositive(value) { return value > 0; }
export function devicePixelField(receiver, key) { return receiver[key]; }