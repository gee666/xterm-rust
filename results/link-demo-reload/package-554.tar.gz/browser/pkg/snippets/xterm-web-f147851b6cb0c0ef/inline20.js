
export function canvasLayerGet(o,k) { return o[k]; }
export function canvasLayerCall(o,k,a) { return o[k](...a); }
