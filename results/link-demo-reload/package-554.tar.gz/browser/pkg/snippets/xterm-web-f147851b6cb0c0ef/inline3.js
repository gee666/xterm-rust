
function sixelMemoryLimit() { return this._opts.pixelLimit * 4; }
function belowPixelLimit(w, h) { return w * h < this._opts.pixelLimit; }
function abovePixelLimit(w, h) { return w * h > this._opts.pixelLimit; }
function squaredPixelLimit() { return Math.floor(Math.sqrt(this._opts.pixelLimit)); }
export function imageSixelMemoryLimit(pixelLimit) {
  return sixelMemoryLimit.call({_opts: {pixelLimit}});
}
export function imageBelowPixelLimit(w, h, pixelLimit) {
  return belowPixelLimit.call({_opts: {pixelLimit}}, w, h);
}
export function imageAbovePixelLimit(w, h, pixelLimit) {
  return abovePixelLimit.call({_opts: {pixelLimit}}, w, h);
}
export function imageSquaredPixelLimit(pixelLimit) {
  return squaredPixelLimit.call({_opts: {pixelLimit}});
}
