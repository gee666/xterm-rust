
// Firefox includes operand names in nonprimitive-conversion diagnostics.
export function serializeRowDifference(endRow, startRow) { return endRow - startRow; }
export function checkSerializeArrayLength(length) { new Array(length); }
