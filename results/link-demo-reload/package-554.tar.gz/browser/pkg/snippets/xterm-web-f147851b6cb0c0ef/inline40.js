
export function imagePaletteInitial(value) {
  if (value > 4096) {
    throw new Error('DecoderOptions.paletteLimit must not exceed 4096');
  }
  // The decoder's WASM i32 argument converts again, then clamps in C++.
  return Math.min((+value) >>> 0, 4096);
}
export function imagePaletteReply(value) {
  return `\x1b[?1;0;${value}S`;
}
