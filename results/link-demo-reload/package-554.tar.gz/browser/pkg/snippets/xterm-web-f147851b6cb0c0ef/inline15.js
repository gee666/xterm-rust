
export function imageFixedGeometryReply(width, height) {
  return '\x1b[?2;0;' + width.toFixed(0) + ';' + height.toFixed(0) + 'S';
}
export function imageSquareGeometryReply(x) {
  return '\x1b[?2;0;' + x + ';' + x + 'S';
}
