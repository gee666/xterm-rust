
export function statusProperty(value, key) { return value[key]; }
export function statusLess(left, right) { return left < right; }
export function statusProgressValue(progress) { return Math.min(Math.max(progress.value, 0), 100); }
