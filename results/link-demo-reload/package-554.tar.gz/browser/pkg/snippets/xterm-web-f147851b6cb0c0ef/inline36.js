
export function imageSixelReleaseWarning(error) {
  return `SIXEL: error while decoding image - ${error}`;
}
